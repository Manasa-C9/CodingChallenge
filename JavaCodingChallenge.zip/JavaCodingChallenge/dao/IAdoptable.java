package com.mns.dao;

public interface IAdoptable {
	 
	 void adopt();
}