package com.mns.exception;

public class NullReferenceException extends Exception {
    public NullReferenceException(String message) {
        super(message);
    }
}