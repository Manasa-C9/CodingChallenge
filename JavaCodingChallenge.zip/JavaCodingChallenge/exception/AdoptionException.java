package com.mns.exception;

public class AdoptionException extends Exception {
    public AdoptionException(String message) {
        super(message);
    }
}